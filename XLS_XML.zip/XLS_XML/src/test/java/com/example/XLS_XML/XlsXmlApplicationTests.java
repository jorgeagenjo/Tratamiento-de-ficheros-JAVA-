package com.example.XLS_XML;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XlsXmlApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.XLS_XML;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XlsXmlApplication {

	public static void main(String[] args) {
		SpringApplication.run(XlsXmlApplication.class, args);
	}

}
